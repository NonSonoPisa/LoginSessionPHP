<!DOCTYPE html>

<?php
ob_start();
session_start();
?>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <link href="style.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Sito Affidabile</title>
</head>
<body>
<div id="home"></div>
<script src="script.js"></script>
<nav id="navbar_top" class="navbar navbar-expand-lg navbar-dark" style="background-color: rgba(3, 26, 58, 0.808);">
    <div class="container">
        <img src="img/logo.img" alt="" width="30" height="30" class="d-inline-block align-text-top">
        <a class="navbar-brand" href="#"> Forms by Pisa </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main_nav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="main_nav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="#home"> Home </a></li>
            </ul>
        </div>
            <form action='index.php' method='post'>
                <button type="submit" >Logout</button>
            </form>
            <img src="img/account.png" alt="" width="30" height="30" class="d-inline-block align-text-top">
        </div>
    </div>
</nav>
<div id="login">
    <h1> Pisano Page </h1>

    <br> <br> <br> <br> <br>
    <?php
    if(isset($_REQUEST['stato']))
    {
        echo "<h3>Benvenuto: ". $_SESSION['username'] . "</h3>";
        echo "<p>Ti sei loggato in data: " . date('d/m/Y'). "</p>";

    }

    echo "</div>";

    ?>
</div>
</body>
</html>