<?php

ob_start();
session_start();

if (isset($_POST['username'])) {
    $user = new Log_in($_POST['username'], $_POST['psw']);
}

class Log_in{
    private $username;
    private $stored_users;
    private $storage = "log.json";
    public $error;
    public $success;

    public function __construct($username, $password){
        $this->username= $username;
        $this->password= $password;
        $this->stored_users = json_decode(file_get_contents($this-> storage), true);

        $this-> login();
    }

    private function login()
    {
        foreach ($this->stored_users as $user) {
            if ($this->username == $user['username']) {
                if ($this->password == $user['password']){
                    session_start();
                    $_SESSION['user'] = $this->username;
                    header("location: accessed.php?stato=1");
                   exit();
                }
            }
        }
        return $this->error = "Wrong username or password";
    }
}
?>

<html>
	<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <link href="style.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Sito Affidabile</title>
	</head>
	<body>
		<div id="home"></div>
		<script src="script.js"></script>
		  <nav id="navbar_top" class="navbar navbar-expand-lg navbar-dark" style="background-color: rgba(3, 26, 58, 0.808);">
			<div class="container">
			  <img src="img/logo.img" alt="" width="30" height="30" class="d-inline-block align-text-top">
			  <a class="navbar-brand" href="#"> Forms by Pisa </a>
			    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main_nav">
			  <span class="navbar-toggler-icon"></span>
			    </button>
			  <div class="collapse navbar-collapse" id="main_nav">
				<ul class="navbar-nav ms-auto">
				  <li class="nav-item"><a class="nav-link" href="#home"> Home </a></li>
				</ul>
			  </div>
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown"> Login</a>
                    <ul class="dropdown-menu dropdown-menu-right">
                        <form action='index.php' method='POST'>
                            <li>
                                <input type="text" placeholder="username" name="username">
                            </li>
                            <li>
                                <input type="password" placeholder="Password" name="psw">
                            </li>
                            <li>
                                <input type="submit" value='username' >Login</input>
                                <li class="nav-item"><a class="nav-link" href="register.php"> Register </a></li>
                            </li>
                        </form>
                    </ul>
                </div>
            </div>
          </nav>
        <div class ="container-sm" id="login">

            <h1> Pisano Page </h1>
            <br> <br> <br> <br> <br>
            <h3> Accedi per poter entrare nel sito</h3>
            <br> <br>

        </div>
        
	</body>
</html>