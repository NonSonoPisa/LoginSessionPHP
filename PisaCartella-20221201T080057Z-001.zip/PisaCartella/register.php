<?php
ob_start();
session_start();
?>

<?
// error_reporting(E_ALL);
// ini_set("display_errors", 1);
?>

<html lang = "it">

<head>
    <title>Sito Affidabile</title>
    <link href = "css/bootstrap.min.css" rel = "stylesheet">
    <link href = "style.css">

    <style>

        header{
            text-align: center;
            background-color: rgba(3, 26, 58, 0.808);
        }

        h1{
            text-align:center;
            color: white;
        }

        body{
            background: rgb(214,214,215);
            background: linear-gradient(90deg, rgba(214,214,215,1) 0%, rgba(241,241,241,1) 35%, rgba(247,247,247,1) 62%);
        }

        #register{
            text-align: center;
            margin-top: 30px;
            margin-left: 140px;
            margin-right: 140px;
            background-color: #609676;
            border: 2px solid rgba(3, 26, 58, 0.808);
        }

        #reg{

        }
    </style>

</head>

<body>
    <header>
            <h1>Registrati</h1>
    </header>
    <div id="register">
        <div class = "container form-signin">

            <?php
            $msg = '';

            if (isset($_POST['login']) && !empty($_POST['username'])
                && !empty($_POST['password'])) {

                if ($_POST['username'] &&
                    $_POST['password']) {
                    $_SESSION['valid'] = true;
                    $_SESSION['timeout'] = time();
                    $_SESSION['username'] = 'pisa';

                    echo 'You have entered valid use name and password';
                }
            }
            ?>
        </div> <!-- /container -->

        <div class = "container">

            <form class = "form-signin" role = "form"
                  action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']);
                  ?>" method = "post">
                <h4 class = "form-signin-heading"><?php echo $msg; ?></h4>
                <input type = "text" class = "form-control"
                       name = "username" placeholder = "username"
                       required autofocus></br></br>
                <input type = "email" class = "form-control"
                       name = "email" placeholder = "email"
                       required autofocus></br></br>
                <input type = "password" class = "form-control"
                       name = "password" placeholder = "password" required>
                <br></br>
                <button class = "btn btn-lg btn-primary btn-block" type = "submit"
                        name = "reg">Register</button>
            </form>
            <?php
            if(isset($_POST['reg'])){

                $new_data = array(

                    "email" => $_POST['email'],
                    "password" => $_POST['password'],
                    "username" => $_POST['username']
                );

                if(filesize("log.json") == 0){
                    $first_record = array($new_data);
                    $data_to_save = $first_record;
                }else{
                    $old_records = json_decode(file_get_contents("log.json"));
                    array_push($old_records, $new_data);
                    $data_to_save = $old_records;
                }

                $encoded_data = json_encode($data_to_save, JSON_PRETTY_PRINT);

                if(!file_put_contents("log.json", $encoded_data, LOCK_EX)){
                    $error = "Error storing message, please try again";
                }else{
                    $success =  "Message is stored successfully";
                }

                header("Location: index.php"); /* Redirect browser */
            }
            exit();
            ?>
        </div>
    </div>
</body>
</html>